package com.ecommerceapp.component

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.ecommerceapp.data.DataOrException
import com.ecommerceapp.model.Product
import com.ecommerceapp.model.ProductsList
import com.ecommerceapp.model.cart.CartProduct
import com.ecommerceapp.screens.cart.CartViewModel

@Composable
fun ProductsRow(
    productlist: DataOrException<ProductsList, Boolean, Exception>,
    navController: NavHostController,
    cartViewModel: CartViewModel
) {
    val context = LocalContext.current
    productlist.data?.response_data?.product.let { productslist ->
        LazyColumn() {
            items(items = productslist!!) { item: Product ->
                Row(
                    modifier = Modifier
                        .padding(5.dp)
                        .background(color = MaterialTheme.colors.background)
                        .clickable {

                        },
                ) {
                    AsyncImage(
                        model = item.photo,
                        contentDescription = "product image",
                        modifier = Modifier
                            .size(80.dp)
                            .padding(2.dp),
                        contentScale = ContentScale.FillBounds
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(all = 4.dp),
                        horizontalAlignment = Alignment.Start,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = item.name,
                            modifier = Modifier.padding(1.dp),
                            color = Color.Red,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Rs" + item.price + "/" + item.unit,
                            modifier = Modifier.padding(1.dp),
                            color = Color.Red,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Normal
                        )
                        //====Quantity section====//
                        if (item.qty == 0) {
                            AddRow(cartViewModel,item)
                        } else {
                             Row(modifier = Modifier.fillMaxWidth(),
                                 horizontalArrangement = Arrangement.End,
                                 verticalAlignment = CenterVertically) {
                                Button(onClick = { /*onUpdate(item.copy(qty = item.qty + 1))*/ }) {
                                    Text(text = "+")
                                }
                                Text(
                                    text = item.qty.toString(),
                                    modifier = Modifier.padding(start = 5.dp, end = 5.dp)
                                )
                                Button(onClick = {
//                                    if (item.qty > 1) /*onUpdate(item.copy(qty = item.qty - 1))*/
//                                    else AddRow(cartViewModel,item)
                                }) {
                                    Text(text = "-")
                                }
                            }
                            //====Quantity section END====//
                        }


                    }
                }
            }
        }
    }
}

@Composable
fun AddRow(cartViewModel: CartViewModel, item: Product) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Button(onClick = {
            cartViewModel.addCartProduct(
                CartProduct(
                    category = item.category,
                    name = item.name,
                    photo = item.photo,
                    price = item.price,
                    unit = item.unit,
                    qty = 1
                )
            )
        }) {
            Text(text = "Add")
        }
    }
}
