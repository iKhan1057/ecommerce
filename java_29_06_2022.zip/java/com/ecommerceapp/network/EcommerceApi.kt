package com.ecommerceapp.network

import com.ecommerceapp.model.ProductsList
import retrofit2.http.GET

interface EcommerceApi {
    @GET("iKhan1057/ecommerce/main/products.json")
    suspend fun getProductList():ProductsList
}