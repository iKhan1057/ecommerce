package com.ecommerceapp.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.ecommerceapp.dao.AddressDao
import com.ecommerceapp.dao.CartDao
import com.ecommerceapp.model.address.Address
import com.ecommerceapp.model.cart.CartProduct
import com.ecommerceapp.utils.DateConverter
import com.ecommerceapp.utils.UUIDConverter

@Database(entities = [Address::class, CartProduct::class], version = 2, exportSchema = false)
@TypeConverters(DateConverter::class, UUIDConverter::class)
abstract class ECommerceDatabase : RoomDatabase() {
    abstract fun addressDao(): AddressDao
    abstract fun cartDao(): CartDao
}