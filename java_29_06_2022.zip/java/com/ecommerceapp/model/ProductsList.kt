package com.ecommerceapp.model

data class ProductsList(
    val response_code: Int,
    val response_data: ResponseData,
    val response_details: String
)