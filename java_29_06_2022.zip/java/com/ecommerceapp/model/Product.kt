package com.ecommerceapp.model

import java.util.*

data class Product(
    val id: UUID = UUID.randomUUID(),
    var category: String,
    var name: String,
    var photo: String,
    var price: String,
    var unit: String,
    var qty:Int = 0
)