package com.ecommerceapp.model

data class ResponseData(
    val product: List<Product>
)