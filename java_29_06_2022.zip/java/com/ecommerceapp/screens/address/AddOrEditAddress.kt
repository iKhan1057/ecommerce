package com.ecommerceapp.screens.address

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.ecommerceapp.model.address.Address
import com.ecommerceapp.utils.UUIDConverter
import kotlinx.coroutines.launch

@Composable
fun AddOrEditAddressScreen(
    navController: NavHostController,
    viewModel: AddressViewModel = hiltViewModel(),
    addressId: String?
) {
    Log.d("TAG", "AddOrEditAddressScreen: $addressId")
    val address =
        viewModel.getSingleAddress(UUIDConverter.uuidFromString(addressId)!!).collectAsState().value
    Column(modifier = Modifier.padding(all = 10.dp)) {
        if (address != null) {
            Text(text = "Address ID:${address._id}")
            Text(text = "Address Name:${address.addressname}")
            Text(text = "Address Address1:${address.address1}")
            Text(text = "Address Address2:${address.address2}")
            Text(text = "Address City:${address.city}")
            Text(text = "Address State:${address.state}")
            Text(text = "Address Country:${address.country}")
            Text(text = "Address Pincode:${address.pincode}")
            Text(text = "Address Mobile:${address.mobile}")
            Text(text = "Address Username:${address.username}")
            Text(text = "Address Userid:${address.userid}")
        }
        Button(onClick = {
            viewModel.updateAddress(
                address.copy(
                    _id = address._id,
                    addressname = "Office",
                    address1 = address.address1,
                    address2 = address.address2,
                    pincode = address.pincode,
                    city = address.city,
                    state = address.state,
                    country = address.country,
                    mobile = address.mobile,
                    userid = address.userid,
                    username = address.username
                )
            )
            val addressupdated =
                viewModel.getSingleAddress(UUIDConverter.uuidFromString(addressId)!!)
            Log.d("TAG", "AddOrEditAddressScreen: updated $addressupdated")
        }) {
            Text(text = "Update ADDRESS")
        }
        val scope = rememberCoroutineScope()
        Button(onClick = {
            scope.launch {
                viewModel.deleteAddress(address)
                navController.popBackStack()
            }
        }) {
            Text(text = "DELETE ADDRESS")
        }
    }
}