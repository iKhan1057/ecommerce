package com.ecommerceapp.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Button
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.ecommerceapp.R
import com.ecommerceapp.component.AppContent
import com.ecommerceapp.component.ProductsRow
import com.ecommerceapp.data.DataOrException
import com.ecommerceapp.model.ProductsList
import com.ecommerceapp.navigation.AppScreenName
import com.ecommerceapp.screens.cart.CartViewModel

@Composable
fun HomeScreen(
    navController: NavHostController,
    homeViewModel: HomeViewModel = hiltViewModel(),
    cartViewModel: CartViewModel = hiltViewModel()
) {
    AppContent(navController, title = stringResource(id = R.string.home), isHome = true) {
        Surface(
            modifier = Modifier
                .fillMaxSize(),
            color = Color.LightGray
        ) {
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(onClick = {
                    navController.navigate(AppScreenName.CART.name)
                }) {
                    Text(text = "GO TO CART")
                }

                val productlist = produceState<DataOrException<ProductsList, Boolean, Exception>>(
                    initialValue = DataOrException(
                        loading = true
                    )
                ) {
                    value = homeViewModel.getProductListData()
                }.value

                if (productlist.loading == true) {
                    CircularProgressIndicator()
                } else {
                    ProductsRow(productlist, navController,cartViewModel)
                }
            }
        }
    }
}


