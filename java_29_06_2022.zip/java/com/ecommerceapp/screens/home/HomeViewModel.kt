package com.ecommerceapp.screens.home

import androidx.lifecycle.ViewModel
import com.ecommerceapp.data.DataOrException
import com.ecommerceapp.model.ProductsList
import com.ecommerceapp.repository.ECommerceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: ECommerceRepository): ViewModel() {

    suspend fun getProductListData(): DataOrException<ProductsList, Boolean, Exception> {
        return repository.getAllProducts()
    }
}